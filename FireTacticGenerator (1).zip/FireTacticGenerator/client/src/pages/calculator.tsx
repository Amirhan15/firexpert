import Calculator from "@/components/Calculator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function CalculatorPage() {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Тактический калькулятор</h1>
        <p className="text-muted-foreground">
          Быстрый расчет пожарно-тактических задач
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Калькулятор</CardTitle>
          </CardHeader>
          <CardContent>
            <Calculator />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Основные формулы</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold">Расход воды</h3>
              <p className="text-sm text-muted-foreground">
                Q = 29.7 × d² × √P
                <br />
                Q - Расход (л/мин)
                <br />
                d - Диаметр насадка (мм)
                <br />
                P - Давление (МПа)
              </p>
            </div>
            <div>
              <h3 className="font-semibold">Необходимый раствор пены</h3>
              <p className="text-sm text-muted-foreground">
                V = A × R × T
                <br />
                V - Объем (л)
                <br />
                A - Площадь (м²)
                <br />
                R - Интенсивность подачи (л/мин/м²)
                <br />
                T - Время (мин)
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}