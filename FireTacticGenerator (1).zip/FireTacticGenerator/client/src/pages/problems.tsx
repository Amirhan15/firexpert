import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProblemGenerator from "@/components/ProblemGenerator";

const problemTypes = [
  { id: "path", label: "Путь пройденный огнем" },
  { id: "area", label: "Площадь пожара" },
  { id: "extinguish", label: "Площадь тушения" },
  { id: "workTime", label: "Время работы" },
  { id: "water", label: "На подвоз воды" },
  { id: "volume", label: "Объемное тушение" },
  { id: "foam", label: "Площадь тушения пенных стволов" },
  { id: "waterNet", label: "Работоспособность водосети" },
  { id: "distance", label: "Предельное расстояние" },
  { id: "complex", label: "Комплексные" },
  { id: "verbal", label: "Устные задачи" }
];

export default function Problems() {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Решение задач по пожарной тактике</h1>
        <p className="text-muted-foreground">
          Выберите тему задачи для практики
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Темы задач</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="path">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-3 gap-2">
              {problemTypes.map((type) => (
                <TabsTrigger key={type.id} value={type.id} className="text-lg">
                  {type.label}
                </TabsTrigger>
              ))}
            </TabsList>
            {problemTypes.map((type) => (
              <TabsContent key={type.id} value={type.id}>
                <ProblemGenerator type={type.id} />
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}