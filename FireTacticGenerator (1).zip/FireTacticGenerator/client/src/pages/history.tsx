import { useQuery } from "@tanstack/react-query";
import { Problem } from "@shared/schema";
import StatisticsCard from "@/components/StatisticsCard";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";

export default function History() {
  const { data: problems } = useQuery<Problem[]>({
    queryKey: ["/api/problems/1"], // TODO: Получить реальный ID пользователя из auth
  });

  const totalProblems = problems?.length || 0;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold">История решений</h1>
        <p className="text-muted-foreground">
          Отслеживание прогресса и просмотр решенных задач
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <StatisticsCard
          title="Всего задач"
          value={totalProblems}
          description="Решено задач"
        />
        <StatisticsCard
          title="За неделю"
          value={problems?.filter(p => 
            new Date(p.createdAt).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000
          ).length || 0}
          description="Задач решено за неделю"
        />
        <StatisticsCard
          title="Среднее время"
          value="5.2"
          description="Минут на задачу"
        />
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Дата</TableHead>
              <TableHead>Тип</TableHead>
              <TableHead>Параметры</TableHead>
              <TableHead>Решение</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {problems?.map((problem) => (
              <TableRow key={problem.id}>
                <TableCell>
                  {format(new Date(problem.createdAt), "dd.MM.yyyy")}
                </TableCell>
                <TableCell className="capitalize">{problem.type}</TableCell>
                <TableCell>
                  {Object.entries(problem.parameters).map(([key, value]) => (
                    <div key={key}>
                      {key}: {value}
                    </div>
                  ))}
                </TableCell>
                <TableCell>
                  {Object.entries(problem.solution).map(([key, value]) => (
                    <div key={key}>
                      {key}: {value}
                    </div>
                  ))}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}