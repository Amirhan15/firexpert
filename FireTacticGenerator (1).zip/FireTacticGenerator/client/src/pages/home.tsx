import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FiArrowRight } from "react-icons/fi";

export default function Home() {
  return (
    <div className="space-y-8">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Добро пожаловать в FIREXPERT</h1>
        <p className="text-lg text-muted-foreground">
          Ваша платформа для обучения и практики пожарной тактики
        </p>
        <Link href="/problems">
          <Button size="lg" className="mt-4">
            Начать обучение <FiArrowRight className="ml-2" />
          </Button>
        </Link>
      </section>

      <div className="grid md:grid-cols-3 gap-6 mt-12">
        <FeatureCard
          title="Генерация задач"
          description="Практикуйтесь на случайно сгенерированных задачах по пожарной тактике"
        />
        <FeatureCard
          title="Справочные материалы"
          description="Полная база справочных материалов всегда под рукой"
        />
        <FeatureCard
          title="Отслеживание прогресса"
          description="Контролируйте свой прогресс обучения и экспортируйте решения"
        />
      </div>
    </div>
  );
}

function FeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}