import { useState } from "react";
import { Input } from "@/components/ui/input";
import ReferenceCard from "@/components/ReferenceCard";
import { FiSearch } from "react-icons/fi";

const referenceData = [
  {
    id: 1,
    title: "Расчет распространения огня",
    content: "Методы расчета скорости распространения огня в различных ситуациях",
    category: "расчеты",
  },
  {
    id: 2,
    title: "Интенсивность подачи воды",
    content: "Стандартные значения интенсивности подачи воды для различных типов пожаров",
    category: "вода",
  },
  {
    id: 3,
    title: "Применение пены",
    content: "Рекомендации по применению пены при тушении пожаров",
    category: "пена",
  },
];

export default function Reference() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = referenceData.filter(
    (item) =>
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold">Справочные материалы</h1>
        <p className="text-muted-foreground">
          Доступ к справочным материалам по пожарной тактике
        </p>
      </div>

      <div className="relative">
        <FiSearch className="absolute left-3 top-3 text-muted-foreground" />
        <Input
          placeholder="Поиск в справочных материалах..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredData.map((item) => (
          <ReferenceCard key={item.id} {...item} />
        ))}
      </div>
    </div>
  );
}