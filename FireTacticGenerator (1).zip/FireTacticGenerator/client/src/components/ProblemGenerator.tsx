import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Problem } from "@shared/schema";

interface ProblemGeneratorProps {
  type: string;
}

type ProblemParameters = Record<string, number | string>;

const buildingTypes = [
  "Административное здание",
  "Библиотека",
  "Жилой дом",
  "Театр",
  "Трамвайное депо"
];

const locations = [
  "в центре",
  "в углу",
  "по середине большей стены",
  "по середине меньшей стены"
];

const seasons = ["Зима", "Весна", "Лето", "Осень"];

export default function ProblemGenerator({ type }: ProblemGeneratorProps) {
  const [problem, setProblem] = useState<Problem | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateRandomInt = (min: number, max: number) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  const generateRandomFromArray = <T,>(array: T[]): T => {
    return array[Math.floor(Math.random() * array.length)];
  };

  const generateProblem = () => {
    let parameters: ProblemParameters = {};
    let template = "";

    switch (type) {
      case "path":
        const pathProblemType = generateRandomInt(1, 5);
        switch (pathProblemType) {
          case 1:
            parameters = {
              vLin: (generateRandomInt(5, 80) / 10).toFixed(1),
              tSl: generateRandomInt(3, 15),
              tBr: generateRandomInt(3, 8)
            };
            template = `Определить путь пройденный огнем, если Vлин=${parameters.vLin} м/мин; tсл. = ${parameters.tSl} мин; tб.р.= ${parameters.tBr} мин.`;
            break;
          case 2:
            parameters = {
              building: generateRandomFromArray(buildingTypes),
              vAc: generateRandomInt(45, 60),
              distance: generateRandomInt(5, 15),
              season: generateRandomFromArray(seasons)
            };
            template = `Определить путь пройденный огнем, если пожар произошел в ${parameters.building}; VАЦ = ${parameters.vAc} км/ч; S = ${parameters.distance} км, сезон года ${parameters.season}.`;
            break;
          // Добавить остальные варианты задач
        }
        break;

      case "area":
        parameters = {
          location: generateRandomFromArray(locations),
          tSl: generateRandomInt(3, 15),
          tBr: generateRandomInt(3, 8),
          length: generateRandomInt(10, 60),
          width: generateRandomInt(10, 30)
        };
        template = `В ${parameters.location} помещения произошло возгорание. Найдите площадь пожара на момент прибытия подразделения, если известно, что tсл = ${parameters.tSl} мин, tб.р. = ${parameters.tBr} мин, помещение размером ${parameters.length} x ${parameters.width} м`;
        break;

      // Добавить остальные типы задач по аналогии
    }

    return { template, parameters };
  };

  const mutation = useMutation({
    mutationFn: async (problem: Partial<Problem>) => {
      const response = await apiRequest("POST", "/api/problems", {
        ...problem,
        userId: 1, // TODO: Получать реальный ID пользователя из auth
        type,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/problems"] });
      toast({
        title: "Задача сохранена",
        description: "Задача добавлена в историю",
      });
    },
  });

  const handleGenerate = () => {
    const { template, parameters } = generateProblem();
    setProblem({
      id: 0,
      userId: 1,
      type,
      parameters: { ...parameters, text: template },
      solution: {},
      createdAt: new Date()
    });
  };

  const handleSave = () => {
    if (problem) {
      mutation.mutate(problem);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-center">
        <Button onClick={handleGenerate} size="lg" className="text-lg">
          Сгенерировать задачу
        </Button>
      </div>

      {problem && (
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-xl mb-4">Условие задачи:</h3>
                <p className="text-lg">
                  {problem.parameters.text as string}
                </p>
              </div>
              <div className="flex justify-end">
                <Button onClick={handleSave}>Сохранить задачу</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}