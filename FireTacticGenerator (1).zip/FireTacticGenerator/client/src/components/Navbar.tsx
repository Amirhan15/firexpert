import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  FiHome, 
  FiBook, 
  FiPercent, 
  FiClock, 
  FiLayout,
  FiSun,
  FiMoon,
  FiBarChart2
} from "react-icons/fi";

export default function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="bg-primary text-primary-foreground shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/">
            <a className="text-2xl font-bold">FIREXPERT</a>
          </Link>

          <div className="hidden md:flex space-x-4">
            <NavLink href="/" icon={<FiHome />} active={location === "/"}>
              Главная
            </NavLink>
            <NavLink href="/problems" icon={<FiLayout />} active={location === "/problems"}>
              Решение задач
            </NavLink>
            <NavLink href="/calculator" icon={<FiPercent />} active={location === "/calculator"}>
              Калькулятор
            </NavLink>
            <NavLink href="/reference" icon={<FiBook />} active={location === "/reference"}>
              Справочник
            </NavLink>
            <NavLink href="/history" icon={<FiClock />} active={location === "/history"}>
              История
            </NavLink>
            <NavLink href="/statistics" icon={<FiBarChart2 />} active={location === "/statistics"}>
              Статистика
            </NavLink>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <FiSun className="h-5 w-5" />
            </Button>
            <Link href="/auth">
              <Button variant="secondary">Войти</Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ href, icon, active, children }: { href: string; icon: React.ReactNode; active: boolean; children: React.ReactNode }) {
  return (
    <Link href={href}>
      <Button
        variant="ghost"
        className={`flex items-center gap-2 ${active ? "bg-primary-foreground/10" : ""}`}
      >
        {icon}
        {children}
      </Button>
    </Link>
  );
}