import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";

type CalculationType = "waterFlow" | "foamSolution";

export default function Calculator() {
  const [calculationType, setCalculationType] = useState<CalculationType>("waterFlow");
  const [inputs, setInputs] = useState<Record<string, number>>({});
  const [result, setResult] = useState<number | null>(null);

  const handleCalculate = () => {
    let calculatedResult: number;

    switch (calculationType) {
      case "waterFlow":
        // Q = 29.7 × d² × √P
        calculatedResult = 29.7 * Math.pow(inputs.diameter || 0, 2) * Math.sqrt(inputs.pressure || 0);
        break;
      case "foamSolution":
        // V = A × R × T
        calculatedResult = (inputs.area || 0) * (inputs.rate || 0) * (inputs.time || 0);
        break;
      default:
        return;
    }

    setResult(Math.round(calculatedResult * 100) / 100);
  };

  const renderInputs = () => {
    switch (calculationType) {
      case "waterFlow":
        return (
          <>
            <div className="space-y-2">
              <Label>Nozzle Diameter (mm)</Label>
              <Input
                type="number"
                value={inputs.diameter || ""}
                onChange={(e) =>
                  setInputs({ ...inputs, diameter: parseFloat(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Pressure (MPa)</Label>
              <Input
                type="number"
                step="0.1"
                value={inputs.pressure || ""}
                onChange={(e) =>
                  setInputs({ ...inputs, pressure: parseFloat(e.target.value) })
                }
              />
            </div>
          </>
        );
      case "foamSolution":
        return (
          <>
            <div className="space-y-2">
              <Label>Area (m²)</Label>
              <Input
                type="number"
                value={inputs.area || ""}
                onChange={(e) =>
                  setInputs({ ...inputs, area: parseFloat(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Application Rate (L/min/m²)</Label>
              <Input
                type="number"
                step="0.1"
                value={inputs.rate || ""}
                onChange={(e) =>
                  setInputs({ ...inputs, rate: parseFloat(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Time (min)</Label>
              <Input
                type="number"
                value={inputs.time || ""}
                onChange={(e) =>
                  setInputs({ ...inputs, time: parseFloat(e.target.value) })
                }
              />
            </div>
          </>
        );
    }
  };

  return (
    <div className="space-y-4">
      <Select
        value={calculationType}
        onValueChange={(value) => {
          setCalculationType(value as CalculationType);
          setInputs({});
          setResult(null);
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select calculation type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="waterFlow">Water Flow Rate</SelectItem>
          <SelectItem value="foamSolution">Foam Solution Volume</SelectItem>
        </SelectContent>
      </Select>

      <div className="space-y-4">{renderInputs()}</div>

      <Button onClick={handleCalculate} className="w-full">
        Calculate
      </Button>

      {result !== null && (
        <div className="mt-4 p-4 bg-muted rounded-lg">
          <p className="font-semibold">Result:</p>
          <p className="text-2xl">
            {result}{" "}
            {calculationType === "waterFlow" ? "L/min" : "L"}
          </p>
        </div>
      )}
    </div>
  );
}
